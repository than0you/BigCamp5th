## R 실습파일


## ----

library(dplyr)
library(ggplot2)
library(ggpubr)
library(GGally)
library(stats)
library(ggbiplot)
library(psych)
library(cluster)

## ----plot1, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
data(iris)
plot(iris$Sepal.Length,iris$Sepal.Width)

## ----plot2, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
plot(iris$Sepal.Length,iris$Sepal.Width, xlab="sepal length", 
     ylab="sepal width",main='Iris')

## ----plot3, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
plot(iris$Sepal.Length,iris$Sepal.Width, xlab="sepal length", 
     ylab="sepal width", main="Iris", pch='+',cex=2,col='red')

## ----plot4, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
plot(iris$Sepal.Length,iris$Sepal.Width, xlab="sepal length", 
     ylab="sepal width", main="Iris", type='l')

## ----plot5, comment=NA, echo=TRUE, out.width= "3.5in",out.height='2in',size='scriptsize'----
oldpar <- par(mfrow=c(1, 2))    # par문은 이전 설정을 반환함
plot(iris$Sepal.Length,iris$Sepal.Width, xlab="sepal length", 
     ylab="sepal width", main="Iris", type='b')
plot(iris$Sepal.Length,iris$Sepal.Width, xlab="sepal length", 
     ylab="sepal width", main="Iris", type='o')
par(oldpar)   # 이전 설정 회복

## ----plot6, comment=NA, echo=TRUE, out.width= "3in",out.height='2in',size='scriptsize'----
attach(iris)
plot(Sepal.Length , Sepal.Width , cex=1.5, pch=20, xlab="length",
     ylab="width", main="Iris")
points(Petal.Length , Petal.Width , cex=1.5, pch="+", col="tomato")

## ----plot7, comment=NA, echo=TRUE, out.width= "3in",out.height='2in',size='scriptsize'----
x <- seq(0, 2*pi, 0.1)
y <- sin(x)
plot(x, y)
lines(x, y, col="purple")

## ----plot8, comment=NA, echo=TRUE, out.width= "3in",out.height='2in',size='scriptsize'----
plot(iris$Sepal.Length,iris$Sepal.Width, xlab="sepal length", 
     ylab="sepal width", main="Iris")
text(iris$Sepal.Length,iris$Sepal.Width, pos=4, cex=0.5 ) 

## ----plot9, comment=NA, echo=TRUE, out.width= "3in",out.height='2in',size='scriptsize'----
plot(iris$Sepal.Length , iris$Sepal.Width , cex=1.5, pch=20, 
     xlab="length", ylab="width", main="Iris")
points(iris$Petal.Length , iris$Petal.Width , cex=1.5, pch="+", 
       col="tomato")
legend("topright", legend=c("Sepal", "Petal"), pch=c(20, 43), 
       col=c("black", "tomato"), bg="ivory")

## ----plot10, comment=NA, echo=TRUE, out.width= "3in",out.height='2in',size='scriptsize'----
pairs(~Sepal.Width + Sepal.Length + Petal.Width + Petal.Length, 
      data=iris, col=c("red", "green", "blue")[iris$Species])


## ----ggplot1, comment=NA,warning=FALSE,message=FALSE,echo=TRUE, out.width= "2in",size='scriptsize'----
library(dplyr)
library(ggplot2)

## ----ggplot2, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
str(mpg)

## ----ggplot3, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(x = displ, y= hwy)) + geom_point()

## ----ggplot4, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ,hwy)) + geom_point()

## ----ggplot5, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ, cty, colour = class)) + geom_point()

## ----ggplot6, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ, cty, shape = drv)) + geom_point()

## ----ggplot7, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ, cty, size = cyl)) + geom_point()

## ----ggplot8, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ, hwy)) + geom_point(aes(colour="blue"))

## ----ggplot9, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ, hwy)) + geom_point(colour="blue")

## ----ggplot10, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ,hwy)) + geom_point() + facet_wrap(~class)

## ----ggplot11, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ,hwy)) +
  geom_point(data=mpg[,c(3,9)], colour="grey70") +
  geom_point(aes(colour=class)) +
  facet_wrap(~class)

## ----ggplot12, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ, hwy))+ geom_point() + geom_smooth()

## ----ggplot17, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(cty, hwy)) +
  geom_point(alpha=1/3) +
  xlim(5,40) + ylim(10,50)

## ----ggplot18, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(cty, hwy)) +
  geom_point(alpha=1/3) +
  xlab("city driving (mpg)") +
  ylab("hightway driving (mpg)")

## ----ggplot19, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(cty, hwy)) +
  geom_point(alpha=1/3) +
  xlab(NULL) + ylab(NULL)

## ----ggplot20, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
pdf("output1.pdf", width=6, height=6)
ggplot(mpg, aes(displ, cty)) + geom_point()
dev.off()

## ----ggplot21, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize',fig.show='hide'----
ggplot(mpg, aes(displ,cty)) + geom_point()
ggsave("output2.pdf")

## ----barplot1, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(drv)) + geom_bar()

## ----barplot4, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(drv,fill=drv)) + geom_bar()

## ----barplot5, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(drv,fill=trans)) + geom_bar()

## ----pieplot1, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(x=1, fill=drv)) +
 geom_bar() +
 coord_polar(theta = "y") +
 theme_void()

## ----hist1, comment=NA, echo=TRUE, message=FALSE,out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(hwy)) + geom_histogram()

## ----hist2, comment=NA, message=FALSE,out.width= "4in",out.height="2.5in",size='scriptsize'----
ggplot(mpg, aes(hwy)) + geom_freqpoly()

## ----hist3, comment=NA, message=FALSE,out.width= "4in",out.height="2in",size='scriptsize'----
ggplot(mpg, aes(displ, colour = drv)) +
  geom_freqpoly(binwidth = 0.5)

## ----hist4, comment=NA, message=FALSE,out.width= "4in",out.height="2in",size='scriptsize'----
ggplot(mpg, aes(displ, fill = drv)) +
  geom_histogram(binwidth=0.5) +
  facet_wrap(~drv, ncol =1)

## ----scatter1, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(faithful,aes(eruptions,waiting))+geom_point()

## ----scatter2, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(displ, cty, colour = class)) + geom_point()

## ----scatter3, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(drv, hwy)) + geom_jitter()

## ----boxplot1, comment=NA, warning=FALSE, echo=TRUE, out.width= "2in",size='scriptsize'----
library(ggpubr)
box1 <- ggplot(faithful, aes(1,eruptions)) + geom_boxplot()
box2 <- ggplot(faithful, aes(1,waiting)) + geom_boxplot()
ggarrange(box1,box2)

## ----boxplot2, comment=NA, echo=TRUE, out.width= "2in",size='scriptsize'----
ggplot(mpg, aes(drv, hwy)) + geom_boxplot()

## ----ex1,comment=NA, size='tiny'-----------------------------------------
cereal = read.csv("./cereals.csv")
head(cereal)
cereal=cereal[,c("name","calories","protein","fat","sodium","fiber","carbo","sugars",
                 "potass","vitamins")]

## ----ex2,comment=NA, size='tiny'-----------------------------------------
cereal[!complete.cases(cereal),]
cereal=cereal[-c(5,21,58),]
rownames(cereal)=cereal[,"name"]
cereal=cereal[,-1]
head(cereal)

## ----ex3,comment=NA, size='tiny'-----------------------------------------
round(cor(cereal),3)

## ----ex4,comment=NA, warning=FALSE, message=FALSE,size='tiny', out.width="2.8in", out.height="2.8in"----
library(GGally)
ggpairs(cereal)

## ----ex5,comment=NA, size='tiny'-----------------------------------------
library(stats)
fit <- princomp(cereal, cor=T)
summary(fit)

## ----ex6,comment=NA, size='tiny'-----------------------------------------
round(fit$loadings[,],3)

## ----ex6.1,comment=NA, size='tiny'---------------------------------------
round(fit$loadings[,1],3)
round(fit$loadings[,2],3) 

## ----ex7,comment=NA, size='tiny', out.width="2in", out.height="2in"------
pcavar=fit$sdev^2
qplot(1:9,pcavar)+geom_line() + 
  xlab("Principal Component") + 
  ylab("Variance") +
  ggtitle("Scree Plot") 

## ----ex8,comment=NA, size='tiny'-----------------------------------------
round(head(fit$scores),3)

## ----ex8.1,comment=NA, size='tiny'---------------------------------------
round(head(predict(fit, cereal)),3)

## ----ex9,comment=NA, warning=FALSE, message=FALSE, size='tiny', out.width="2.5in", out.height="2.5in"----
library(ggbiplot)
ggbiplot(fit,labels=rownames(cereal))

## ----ex9.1,comment=NA, size='tiny', out.width="2.7in", out.height="2.7in", echo=FALSE----
ggbiplot(fit,labels=rownames(cereal))

## ----ex20,comment=NA, warning=FALSE, message=FALSE, size='tiny'----------
library(psych)
fit1 = principal (cereal, nfactors=3, rotate="none")

## ----ex21,comment=NA, size='tiny'----------------------------------------
fit1$loadings

## ----ex22,comment=NA, size='tiny'----------------------------------------
fit2= principal (cereal, nfactors=3, rotate="varimax")
fit2$loadings

## ----ex23,comment=NA, size='tiny', out.width="2in", out.height="2in"-----
fa1=data.frame(fit1$loadings[,1:2])
fa2=data.frame(fit2$loadings[,1:2])
qplot(x=c(-1,1), y=c(-1,1),geom='blank') + 
  xlab("Component 1") + ylab("Component 1") +
  geom_hline(yintercept=0, color="darkgray")+geom_vline(xintercept=0, color="darkgray")+
  geom_text(data=fa1, mapping=aes(x=PC1, y=PC2, label=rownames(fa1)), 
            size=6,col='blue')+
  geom_text(data=fa2, mapping=aes(x=RC1, y=RC2, label=rownames(fa2)), 
            size=6,col='red')

## ----europe1,comment=NA, size='tiny',warning=FALSE-----------------------
europe=read.csv("./EuropeanJobs.csv")
head(europe)
rownames(europe)=europe[,"Country"]
europe=europe[,-(1:2)]
head(europe)

## ----europe2,comment=NA, size='tiny',warning=FALSE-----------------------
library(cluster)
set.seed(2018)
clustering.k4 <- kmeans(europe, 4)
clustering.k4


## ----europe3,comment=NA, size='tiny',warning=FALSE,message=FALSE,out.width="2.8in", out.height="2.8in"----
europe2=europe
europe2$cluster=as.factor(clustering.k4$cluster)
ggpairs(europe2,mapping=ggplot2::aes(colour = cluster))

## ----europe4,comment=NA, size='tiny',warning=FALSE,out.width="2.8in", out.height="2.8in"----
set.seed(2018)
clustering1 <- kmeans(europe,4)
set.seed(2020)
clustering2 <- kmeans(europe,4)
table(clustering1$cluster, clustering2$cluster)


## ----europe5,comment=NA, size='tiny',warning=FALSE,out.width="2.8in", out.height="2.8in"----
clustering1$centers

clustering2$centers


## ----europe6,comment=NA, size='tiny',warning=FALSE,out.width="2.5in", out.height="2.5in"----
fit = princomp(europe,cor=TRUE)
europefa=data.frame(fit$scores[,1:2])
europefa$cluster=as.factor(clustering.k4$cluster)
ggplot(europefa,aes(Comp.1, Comp.2,label=rownames(europefa),colour=cluster))+
  geom_text()+xlim(-6,6)+ylim(-3,3)

